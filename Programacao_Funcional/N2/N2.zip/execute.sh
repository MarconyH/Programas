#!/bin/bash

ghc /home/marcony/Documents/Programas/Programacao_Funcional/N2/n2.hs && rm /home/marcony/Documents/Programas/Programacao_Funcional/N2/n2.hi /home/marcony/Documents/Programas/Programacao_Funcional/N2/n2.o
/home/marcony/Documents/Programas/Programacao_Funcional/N2/n2
